<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

if(isset($_POST['submit'])){

    $selected = $_POST['symptoms'];
    $selectedString = implode(",", $selected);

    $result = $conn->query("SELECT * FROM diseases");

    $bestMatch = "";
    $maxMatch = 0;
    $description = "";

    while($row = $result->fetch_assoc()){
        $diseaseSymptoms = array_map('trim', explode(",", $row['symptoms']));
        $matchCount = count(array_intersect($selected, $diseaseSymptoms));

        if($matchCount > $maxMatch){
            $maxMatch = $matchCount;
            $bestMatch = $row['disease_name'];
            $description = $row['description'];
        }
    }

    $user_id = $_SESSION['user_id'];

    $conn->query("INSERT INTO user_reports(user_id,selected_symptoms,predicted_disease)
                  VALUES('$user_id','$selectedString','$bestMatch')");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Prediction Result</title>
<style>

body{
    font-family:Arial;
    background:#f8f9fc;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.result-card{
    background:white;
    padding:30px;
    border-radius:10px;
    width:500px;
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

h2{
    color:#e74a3b;
}

a{
    display:inline-block;
    margin-top:15px;
    text-decoration:none;
    background:#4e73df;
    color:white;
    padding:8px 15px;
    border-radius:5px;
}

</style>
</head>
<body>

<div class="result-card">
    <h2>Predicted Disease:</h2>
    <h3><?php echo $bestMatch; ?></h3>

    <p><?php echo $description; ?></p>

    <a href="dashboard.php">Back to Dashboard</a>
</div>

</body>
</html>