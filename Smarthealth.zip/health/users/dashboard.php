<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();
$diseases = $conn->query("SELECT * FROM diseases");

$allSymptoms = [];

while($row = $diseases->fetch_assoc()){
    $symptoms = explode(",", $row['symptoms']);
    foreach($symptoms as $sym){
        $sym = trim($sym);
        if(!in_array($sym, $allSymptoms)){
            $allSymptoms[] = $sym;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>User Dashboard</title>
<style>

body{
    margin:0;
    font-family:Arial, sans-serif;
    background:#f4f6f9;
}

.navbar{
    background:#4e73df;
    padding:15px;
    color:white;
    display:flex;
    justify-content:space-between;
}

.container{
    padding:30px;
}

.card{
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    margin-bottom:20px;
}

.symptoms-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
    gap:10px;
}

.symptom-item{
    background:#e3e6f0;
    padding:10px;
    border-radius:8px;
}

button{
    background:#1cc88a;
    color:white;
    padding:10px 20px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    margin-top:15px;
}

button:hover{
    background:#17a673;
}

.logout{
    color:white;
    text-decoration:none;
}

</style>
</head>
<body>

<div class="navbar">
    <div>Welcome, <?php echo $user['name']; ?></div>
    <div><a class="logout" href="logout.php">Logout</a></div>
</div>

<div class="container">

<div class="card">
    <h3>Select Your Symptoms</h3>

    <form action="select_symptoms.php" method="POST">
        <div class="symptoms-grid">

        <?php foreach($allSymptoms as $symptom): ?>
            <div class="symptom-item">
                <label>
                    <input type="checkbox" name="symptoms[]" value="<?php echo $symptom; ?>">
                    <?php echo $symptom; ?>
                </label>
            </div>
        <?php endforeach; ?>

        </div>

        <button type="submit" name="submit">Predict Disease</button>
    </form>
</div>

</div>

</body>
</html>