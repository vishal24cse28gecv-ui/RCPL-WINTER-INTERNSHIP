<?php
session_start();
include("../config/db.php");

$error = "";

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE email='$email'");

    if($result && $result->num_rows > 0){
        $user = $result->fetch_assoc();

        if(password_verify($password,$user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];

            setcookie("user_email",$user['email'],time()+3600,"/");

            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid Password!";
        }
    } else {
        $error = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f6c23e, #36b9cc);
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            margin:0;
        }

        .card{
            background:white;
            padding:30px;
            border-radius:10px;
            width:350px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            margin-bottom:20px;
        }

        input{
            width:100%;
            padding:10px;
            margin:8px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:#f6c23e;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
            font-size:16px;
        }

        button:hover{
            background:#dda20a;
        }

        .error{
            color:red;
            text-align:center;
            margin-bottom:10px;
        }

        .register-link{
            text-align:center;
            margin-top:15px;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>User Login</h2>

    <?php if($error){ ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login">Login</button>
    </form>

    <div class="register-link">
        Don't have account? <a href="register.php">Register</a>
    </div>
</div>

</body>
</html>