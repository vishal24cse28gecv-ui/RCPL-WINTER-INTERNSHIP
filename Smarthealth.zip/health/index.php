<?php
session_start();

// If already logged in → redirect
if(isset($_SESSION['admin_id'])){
    header("Location: admin/dashboard.php");
    exit();
}

if(isset($_SESSION['user_id'])){
    header("Location: user/dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Healthcare System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            text-align: center;
        }
        .home-box {
            margin-top: 100px;
        }
        .btn {
            display: inline-block;
            padding: 12px 20px;
            margin: 10px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="home-box">
    <h1>🏥 Healthcare Management System</h1>
    <p>Welcome to Smart Symptom Based Disease Prediction Portal</p>

    <h3>Doctor Panel</h3>
    <a class="btn" href="admin/login.php">Doctor Login</a>
    <a class="btn" href="admin/register.php">Doctor Register</a>

    <hr style="width: 300px; margin: 30px auto;">

    <h3>User Panel</h3>
    <a class="btn" href="users/login.php">User Login</a>
    <a class="btn" href="users/register.php">User Register</a>

</div>

</body>
</html>