<?php
session_start();
include("../config/db.php");

$error = "";

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $location = $_POST['location'];
    $profile = $_POST['profile'];

    $sql = "INSERT INTO admins(name,email,password,location,profile_url)
            VALUES('$name','$email','$password','$location','$profile')";

    if($conn->query($sql)){
        header("Location: login.php");
        exit();
    } else {
        $error = "Something went wrong!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Register</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4e73df, #1cc88a);
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            margin:0;
        }

        .card{
            background:white;
            padding:30px;
            border-radius:10px;
            width:350px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            margin-bottom:20px;
        }

        input{
            width:100%;
            padding:10px;
            margin:8px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:#4e73df;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
            font-size:16px;
        }

        button:hover{
            background:#2e59d9;
        }

        .error{
            color:red;
            text-align:center;
        }

        .login-link{
            text-align:center;
            margin-top:15px;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Admin Register</h2>

    <?php if($error){ ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="text" name="profile" placeholder="Profile Image URL" required>

        <button type="submit" name="register">Register</button>
    </form>

    <div class="login-link">
        Already have account? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>