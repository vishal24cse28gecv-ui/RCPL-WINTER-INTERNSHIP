document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", () => {
        alert("Processing...");
    });
});